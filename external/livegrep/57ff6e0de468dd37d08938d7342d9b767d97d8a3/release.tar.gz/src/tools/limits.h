#ifndef CODESEARCH_LIMITS_H
#define CODESEARCH_LIMITS_H

const int kMaxProgramSize = 4000;
const int kMaxWidth       = 200;

#endif
